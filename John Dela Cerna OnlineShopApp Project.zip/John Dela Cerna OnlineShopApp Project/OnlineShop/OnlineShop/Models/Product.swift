//
//  Products.swift
//  OnlineShop
//
//  Created by John Dela Cerna on 12/17/22.
//

import Foundation

struct Product: Identifiable {
    var id = UUID()
    var name: String
    var image: String
    var price: Int
    
}
var productList = [Product(name: "Jordan 1 Lost & Found Size 8.5", image: "shop1", price: 400),
                    Product(name: "Jordan 4 Violet Ore Size 9", image: "shop2", price: 450),
                    Product(name: "Supreme Box Logo Crewneck Size L", image: "shop3", price: 300),
                    Product(name: "24k Cuban Link gold neklace 20 inches", image: "shop4", price: 4500),
                    Product(name: "Stone Island Cargo Pants Size L", image: "shop5", price: 700),
                    Product(name: "Rolex Submariner Gold", image: "shop6", price: 12000),
                    Product(name: "Louis Vuitton Christopher MM", image: "shop7", price: 4500),
                    Product(name: "Birkenstock Boston Size 10", image: "shop8", price: 120)]
